<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="back4tiles1" tilewidth="16" tileheight="16" tilecount="9344" columns="146">
 <image source="181b8c8f33fe852f398e346f13ccda8e.jpeg" width="2340" height="1032"/>
</tileset>
