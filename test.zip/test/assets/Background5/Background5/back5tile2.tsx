<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="back5tile2" tilewidth="16" tileheight="16" tilecount="3150" columns="75">
 <image source="Tanstarsback2.png" width="1200" height="675"/>
</tileset>
