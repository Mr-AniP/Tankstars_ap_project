<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="back6tiles1" tilewidth="16" tileheight="16" tilecount="8040" columns="120">
 <image source="ded00065333621.5af0ea8ca2b29.png" width="1920" height="1080"/>
</tileset>
