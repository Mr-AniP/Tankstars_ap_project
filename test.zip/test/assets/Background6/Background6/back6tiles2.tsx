<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="back6tiles2" tilewidth="16" tileheight="16" tilecount="9344" columns="146">
 <image source="Terrain3.jpeg" width="2340" height="1032"/>
</tileset>
