package com.approject.tankstars;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;

public class Gamescreen implements Screen {
	final MytankstarsGame mygame;
	OrthographicCamera camera;
	Texture backgroundTexture;
	public Gamescreen(MytankstarsGame myGame) {
		this.mygame=myGame;
		camera=new OrthographicCamera();
		camera.setToOrtho(false, 1200, 561);
	}
	@Override
	public void show() {
		backgroundTexture = new Texture(Gdx.files.internal("gameback.png"));
	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		camera.update();
		mygame.batch.setProjectionMatrix(camera.combined);
		mygame.batch.begin();
		mygame.batch.draw(backgroundTexture,0,0);
		mygame.batch.end();
		if(Gdx.input.justTouched())
		{
			Vector3 tmp=new Vector3(Gdx.input.getX(),Gdx.input.getY(),0);
			camera.unproject(tmp);
			Rectangle b1=new Rectangle(25,440,70,100);
			if(b1.contains(tmp.x,tmp.y))
			{
				new Thread(new Runnable() {
					@Override
					public void run() {
						long cortime=System.currentTimeMillis();
						while(System.currentTimeMillis()-cortime<100);
						Gdx.app.postRunnable(new Runnable() {
							@Override
							public void run() {
								mygame.setScreen(new Pausescreen(mygame));
							}
						});
					}
				}).start();
			}
		}
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub

	}

}
