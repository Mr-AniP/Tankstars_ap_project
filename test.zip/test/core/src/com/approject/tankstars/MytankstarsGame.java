package com.approject.tankstars;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;


public class MytankstarsGame extends Game {
	public SpriteBatch batch;
	public BitmapFont fontstyle;
    public int tankchosen_1=0;
	public int tankchosen_2=1;
	Newgame currentgame;

	public void create() {
		batch = new SpriteBatch();
		fontstyle = new BitmapFont();
		this.setScreen(new LoadScreen(this));
	}

	public void render() {
		super.render();
	}

	public void dispose() {
		batch.dispose();
		fontstyle.dispose();
	}
}
