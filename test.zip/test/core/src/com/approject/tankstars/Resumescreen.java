package com.approject.tankstars;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton.TextButtonStyle;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener.ChangeEvent;
import com.badlogic.gdx.utils.ScreenUtils;

public class Resumescreen implements Screen {
	final MytankstarsGame mygame;
	OrthographicCamera camera;
	private Stage stage;
	private TextButtonStyle style;
	TextButton button1,button2,button3;
	public Resumescreen(MytankstarsGame myGame) {
		this.mygame=myGame;
		this.camera=new OrthographicCamera();
		camera.setToOrtho(false, 800, 480);
		stage = new Stage();
		Gdx.input.setInputProcessor(stage);
		Table table=new Table();
		table.setFillParent(true);
		stage.addActor(table);
		mygame.fontstyle.getData().setScale(2, 3);
		style = new TextButtonStyle();
		style.font = mygame.fontstyle;
		table.center().center();
		button1 = new TextButton("SAVED GAME 1", style);
		button2 = new TextButton("SAVED GAME 2", style);
		button3 = new TextButton("EXIT", style);
		
		button1.setWidth(300);
        button1.setHeight(150);
        button1.setX(Gdx.graphics.getWidth() / 2 - button2.getWidth() / 2);
        button1.setY((float) (Gdx.graphics.getHeight() / 1.5));
        
        button2.setWidth(300);
        button2.setHeight(150);
        button2.setX(Gdx.graphics.getWidth() / 2 - button2.getWidth() / 2);
        button2.setY((float) (Gdx.graphics.getHeight()/2 -button2.getHeight()/2));
        
        button3.setWidth(300);
        button3.setHeight(150);
        button3.setX(Gdx.graphics.getWidth() / 2 - button2.getWidth() / 2);
        button3.setY((float) (Gdx.graphics.getHeight()/2 -button2.getHeight()/2)-150);
        
        stage.addActor(button1);
        stage.addActor(button2);
        stage.addActor(button3);
	}
	@Override
	public void show() {
		// TODO Auto-generated method stub

	}

	@Override
	public void render(float delta) {
		ScreenUtils.clear(0.3f, 0.2f, 0.5f, 1);

		camera.update();
		mygame.batch.setProjectionMatrix(camera.combined);
		ScreenUtils.clear(0.8f, 0, 0, 1);
		
		stage.act(delta);
		camera.update();
		mygame.batch.setProjectionMatrix(camera.combined);
		mygame.batch.begin();
		
		stage.draw();
	    mygame.batch.end();
	    
	    button1.addListener(new ChangeListener() {
	        public void changed (ChangeEvent event, Actor actor) {
				mygame.setScreen(new Gamescreen(mygame));
	        }
	    });
	    button2.addListener(new ChangeListener() {
	        public void changed (ChangeEvent event, Actor actor) {
				mygame.setScreen(new Gamescreen(mygame));
	        }
	    });
	    button3.addListener(new ChangeListener() {
	        public void changed (ChangeEvent event, Actor actor) {
				System.exit(0);
	        }
	    });

	}

	@Override
	public void resize(int width, int height) {
		stage.getViewport().update(width, height, true);

	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		stage.dispose();
	}
}
