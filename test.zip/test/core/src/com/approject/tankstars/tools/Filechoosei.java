package com.approject.tankstars.tools;

import javax.swing.*;
import javax.swing.filechooser.FileSystemView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Filechoosei extends JFrame implements ActionListener {
    public JLabel l;
    public void fn2() {
        JFrame f = new JFrame("file chooser");
        f.setSize(400, 400);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JButton button2 = new JButton("open");
        Filechoosei f1 = new Filechoosei();
        button2.addActionListener(f1);
        JPanel p = new JPanel();
        p.add(button2);
        l = new JLabel("nope nope");
        p.add(l);
        f.add(p);
        f.show();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String com = e.getActionCommand();
        JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        // invoke the showsOpenDialog function to show the save dialog
        int r = j.showOpenDialog(null);
        if (r == JFileChooser.APPROVE_OPTION) {
            l.setText(j.getSelectedFile().getAbsolutePath());}
        else
            l.setText("nope nope");
    }

}
